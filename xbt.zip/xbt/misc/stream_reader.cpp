#include "stdafx.h"
#include "stream_reader.h"

